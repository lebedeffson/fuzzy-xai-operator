"""P19 system-operator contracts: uncertainty, reduction, E_pre, and rho."""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass
from typing import Any

from fuzzyxai.core.explain_plan import ExplainPlan, MembershipPolicy
from fuzzyxai.core.explanation_object import ExplanationObject, Rule, Trace
from fuzzyxai.hierarchy.f0 import F0
from fuzzyxai.hierarchy.interval import IntervalFS
from fuzzyxai.hierarchy.reductions import reduce_to_f0
from fuzzyxai.scientific_alignment import AlignmentTransform, compute_real_alignment
from fuzzyxai.trust.trust_evaluator import (
    compute_interpretability_index,
    compute_interpretability_loss,
    entropy_component,
    rule_complexity_component,
    rule_contradiction_component,
    term_overlap_component,
)


def _clip01(value: float) -> float:
    return max(0.0, min(1.0, float(value)))


@dataclass(frozen=True)
class UncertaintyEvidence:
    u_model: float | None
    u_rules: float | None
    u_trace: float | None
    u_m: float | None
    status: str
    weights: dict[str, float]
    sources: dict[str, Any]


@dataclass(frozen=True)
class SystemObservation:
    """Factual inputs for one declared system-operator route.

    This belongs in :class:`ObservationContext`: it records the target
    interface and observed trace/rule facts for this run.  Thresholds,
    weights, and whether the operators are allowed remain in ExplainPlan.
    """

    alignment_transform: AlignmentTransform
    risk_membership_policy: MembershipPolicy
    risk_class: Any
    trace: Trace
    model_trace: Trace | None = None
    trace_complete: bool = True
    rule_conflict: float = 0.0
    rules_applicable: bool = True
    source_refs: tuple[str, ...] = ()


def _object_dict(value: ExplanationObject) -> dict[str, Any]:
    return {
        "terms": sorted(value.terms),
        "representation": getattr(value.representation, "label", type(value.representation).__name__),
        "rules": [rule.signature() for rule in value.rules],
        "activations": dict(value.activations),
        "uncertainty": value.uncertainty,
        "trace": value.trace.as_dict(),
        "reduction_loss": value.reduction_loss,
        "metadata": dict(value.metadata),
    }


@dataclass(frozen=True)
class SystemEvidence:
    """Canonical persisted result of one executed system-operator route."""

    e_model: ExplanationObject
    alignment_transform: Any
    aligned_explanation: ExplanationObject
    e_target: ExplanationObject
    alignment: dict[str, Any]
    uncertainty: UncertaintyEvidence
    representation: Any
    reduction: ReductionEvidence | None
    e_pre: ExplanationObject
    i_pre: float
    risk: SystemRisk
    diagnostics: tuple[dict[str, Any], ...]

    def audit_dict(self) -> dict[str, Any]:
        return {
            "E_model": _object_dict(self.e_model),
            "alignment_transform": self.alignment_transform.to_dict(),
            "aligned_E_model": _object_dict(self.aligned_explanation),
            "E_target": _object_dict(self.e_target),
            "gamma": {key: value for key, value in self.alignment.items() if key != "aligned"},
            "uncertainty": self.uncertainty.__dict__,
            "representation": getattr(self.representation, "class_name", type(self.representation).__name__),
            "reduction": None if self.reduction is None else self.reduction.__dict__,
            "E_pre": _object_dict(self.e_pre),
            "i_pre": {"value": self.i_pre, "formula": "exp(-L(E_pre))", "weights": self.e_pre.metadata.get("interpretability_weights", {}), "components": self.e_pre.metadata.get("interpretability_components", {}), "input_refs": ["E_pre", "ExplainPlan.lambda"]},
            "risk": dict(self.risk.__dict__),
            "diagnostics": list(self.diagnostics),
        }


def build_system_evidence(
    *,
    object_id: str,
    model_fingerprint: str,
    prediction: Any,
    internal_evidence: Mapping[str, Any],
    plan: ExplainPlan,
    observation: SystemObservation,
) -> SystemEvidence:
    """Run the P19 operator chain once from native evidence and factual context."""

    raw_votes = internal_evidence.get("ensemble_votes")
    votes: list[Any] = []
    if isinstance(raw_votes, list):
        for item in raw_votes:
            value = item[0] if isinstance(item, (list, tuple)) and item else item
            votes.append(value)
    if not votes:
        raise ValueError("system route requires native ensemble_votes")
    p_risk = sum(1 for value in votes if value == observation.risk_class) / len(votes)
    vote_counts = {str(value): sum(1 for item in votes if item == value) for value in sorted(set(votes), key=str)}
    vote_proportions = {label: count / len(votes) for label, count in vote_counts.items()}
    disagreement = internal_evidence.get("ensemble_disagreement")
    if not isinstance(disagreement, (float, int)):
        raise TypeError("system route requires measured ensemble_disagreement")
    u_model = _clip01(float(disagreement))
    stamp_trace = observation.model_trace or Trace(
        id=str(object_id), version=model_fingerprint[:12], timestamp=observation.trace.timestamp,
        params={"vote_count": len(votes), "risk_class": observation.risk_class},
        source="native_ensemble_votes", checksum=f"{object_id}:votes:{len(votes)}:{p_risk:.12g}",
    )
    e_model = ExplanationObject(
        terms={"ensemble:benign", "ensemble:malignant"},
        representation=F0(lambda _x, value=p_risk: value, "malignant_vote_proportion"),
        rules=[
            Rule("ensemble_benign", {"vote": "benign"}, "benign"),
            Rule("ensemble_malignant", {"vote": "malignant"}, "malignant"),
        ],
        activations={"ensemble_benign": 1.0 - p_risk, "ensemble_malignant": p_risk},
        uncertainty=u_model, trace=stamp_trace,
        metadata={"interface": observation.alignment_transform.source_interface, "evidence": "per_tree_predictions", "risk_probability": p_risk},
    )
    memberships = observation.risk_membership_policy.evaluate(p_risk)
    strongest = max(memberships.values())
    target_terms = {f"risk:{label}" for label in memberships}
    e_target = ExplanationObject(
        terms=target_terms,
        representation=F0(lambda _x, value=strongest: value, "risk_membership_partition"),
        rules=[
            Rule("risk_low", {"p_malignant": "low"}, "accept"),
            Rule("risk_medium", {"p_malignant": "medium"}, "review"),
            Rule("risk_high", {"p_malignant": "high"}, "defer"),
        ],
        activations={f"risk_{label}": value for label, value in memberships.items()},
        uncertainty=_clip01(1.0 - strongest), trace=observation.trace,
        metadata={"interface": observation.alignment_transform.target_interface, "membership_policy": observation.risk_membership_policy.to_dict(), "memberships": memberships},
    )
    alignment = compute_real_alignment(e_model, e_target, plan=plan, transform=observation.alignment_transform)
    if alignment.get("gamma") is None or not isinstance(alignment.get("aligned"), ExplanationObject):
        raise ValueError(f"system alignment is incomplete: {alignment.get('missing_components') or alignment.get('reason')}")
    aligned = alignment["aligned"]
    u_rules = None if not observation.rules_applicable else _clip01(max(float(observation.rule_conflict), 1.0 - strongest))
    u_trace = 0.0 if observation.trace_complete else 1.0
    uncertainty = aggregate_uncertainty(
        u_model=u_model, u_rules=u_rules, u_trace=u_trace, plan=plan,
        required={"model": True, "rules": observation.rules_applicable, "trace": True},
    )
    if uncertainty.u_m is None:
        raise ValueError("system route has incomplete uncertainty profile")
    interval = IntervalFS(
        lambda _x, value=p_risk, width=u_model: max(0.0, value - width),
        lambda _x, value=p_risk, width=u_model: min(1.0, value + width),
    )
    _, reduction = reduce_interval_representation(interval, delta_threshold=plan.delta_critical)
    uncertainty_values = {"model": u_model, "rules": u_rules, "trace": u_trace}
    aggregation_terms: dict[str, float] = {}
    for key, weight in uncertainty.weights.items():
        component = uncertainty_values[key]
        if component is not None:
            aggregation_terms[key] = weight * component
    uncertainty = UncertaintyEvidence(
        uncertainty.u_model, uncertainty.u_rules, uncertainty.u_trace, uncertainty.u_m, uncertainty.status, uncertainty.weights,
        {"U_model": {"value": u_model, "status": "measured", "method": "ensemble_vote_standard_deviation", "inputs": {"per_tree_votes": list(votes), "vote_count": len(votes), "vote_counts": vote_counts, "vote_proportions": vote_proportions, "risk_class": observation.risk_class, "risk_probability": p_risk}, "formula": "std(per_tree_predictions)", "source_refs": ["ensemble_votes"]},
         "U_rules": {"value": u_rules, "status": "measured" if observation.rules_applicable else "not_applicable", "coverage_component": 1.0 - strongest, "conflict_component": observation.rule_conflict, "applicable_rule_ids": ["risk_low", "risk_medium", "risk_high"], "activations": memberships, "formula": "max(rule_conflict, 1-max(rule_activations))", "source_refs": list(observation.source_refs)},
         "U_trace": {"value": u_trace, "status": "measured", "required_fields": ["id", "version", "timestamp", "source", "checksum"], "missing_fields": [] if observation.trace_complete else ["checkpoint"], "invalid_fields": [], "formula": "0 if required trace is verified else 1", "source_refs": [observation.trace.source]},
         "aggregation": {"eta": uncertainty.weights, "terms": aggregation_terms, "u_M": uncertainty.u_m, "formula": "sum(eta_k * U_k)"}},
    )
    e_pre = compose_pre_explanation(aligned_model=aligned, target=e_target, uncertainty=uncertainty, reduction=reduction)
    components = {"H": entropy_component(e_pre), "C": rule_complexity_component(e_pre), "O": term_overlap_component(e_pre), "K": rule_contradiction_component(e_pre), "U": e_pre.uncertainty}
    e_pre.metadata.update({"interpretability_components": components, "interpretability_weights": dict(plan.lambda_), "interpretability_loss": compute_interpretability_loss(e_pre, plan.lambda_)})
    i_pre = interpretability_pre(e_pre, plan)
    risk_weights = dict(plan.metadata.get("system_risk_weights", {"w_p": 0.30, "w_u": 0.25, "w_I": 0.20, "w_Delta": 0.15, "w_R": 0.10}))
    thresholds = dict(plan.metadata.get("system_risk_thresholds", {"theta_1": plan.rho_accept, "theta_2": plan.rho_warning, "theta_3": plan.rho_audit}))
    critical = int(not bool(alignment["certified"]) or not observation.trace_complete)
    risk = compute_strict_rho(rho_p=p_risk, u_m=uncertainty.u_m, i_pre=i_pre, delta=reduction.delta, chi_r=float(critical), weights=risk_weights, thresholds=thresholds, critical=critical)
    diagnostics = []
    if critical:
        diagnostics.append({"code": "D_risk_critical", "reason": "critical structural rupture overrides numeric action", "severity": "critical"})
    return SystemEvidence(
        e_model=e_model, alignment_transform=observation.alignment_transform, aligned_explanation=aligned,
        e_target=e_target, alignment={key: value for key, value in alignment.items() if key != "aligned"},
        uncertainty=uncertainty, representation=interval, reduction=reduction, e_pre=e_pre, i_pre=i_pre,
        risk=risk, diagnostics=tuple(diagnostics),
    )


def aggregate_uncertainty(*, u_model: float | None, u_rules: float | None, u_trace: float | None, plan: ExplainPlan, required: Mapping[str, bool]) -> UncertaintyEvidence:
    values = {"model": u_model, "rules": u_rules, "trace": u_trace}
    missing = [name for name, enabled in required.items() if enabled and values[name] is None]
    if missing:
        return UncertaintyEvidence(u_model, u_rules, u_trace, None, "incomplete", dict(plan.eta), {"missing": ",".join(missing)})
    used = {name: _clip01(value) for name, value in values.items() if required.get(name, False) and value is not None}
    weights = {name: float(plan.eta[name]) for name in used}
    if not used:
        return UncertaintyEvidence(u_model, u_rules, u_trace, None, "not_applicable", weights, {})
    if abs(sum(weights.values()) - 1.0) > 1e-9:
        return UncertaintyEvidence(u_model, u_rules, u_trace, None, "incomplete", weights, {"reason": "ExplainPlan eta must sum to one over required uncertainty channels"})
    return UncertaintyEvidence(u_model, u_rules, u_trace, sum(weights[key] * used[key] for key in used), "measured", weights, {})


@dataclass(frozen=True)
class ReductionEvidence:
    source_representation: str
    target_representation: str
    operation: str
    inverse_embedding: str
    distance_method: str
    delta: float
    delta_threshold: float
    status: str
    source_interval: tuple[float, float]
    reduced_scalar: float
    reconstructed_interval: tuple[float, float]
    distance_terms: dict[str, float]


def reduce_interval_representation(source: IntervalFS, *, delta_threshold: float) -> tuple[F0, ReductionEvidence]:
    """Perform F_int -> F0 -> iota(F0) and measure D_F, not presentation loss."""
    reduced, declared_delta = reduce_to_f0(source)
    inverse = IntervalFS(reduced.mu, reduced.mu)
    measured = float(source.distance(inverse))
    low, high = (float(value) for value in source.membership(0.0))
    scalar = float(reduced.membership(0.0))
    return reduced, ReductionEvidence(
        source_representation="F_int", target_representation="F0", operation="Pi_interval_midpoint",
        inverse_embedding="iota_F0_to_interval_diagonal", distance_method="IntervalFS.sup_grid_distance",
        delta=measured, delta_threshold=float(delta_threshold), status="measured" if measured == declared_delta else "inconsistent",
        source_interval=(low, high), reduced_scalar=scalar, reconstructed_interval=(scalar, scalar),
        distance_terms={"lower_abs": abs(low - scalar), "upper_abs": abs(high - scalar), "D_F": measured},
    )


def compose_pre_explanation(*, aligned_model: ExplanationObject, target: ExplanationObject, uncertainty: UncertaintyEvidence, reduction: ReductionEvidence | None) -> ExplanationObject:
    if uncertainty.u_m is None:
        raise ValueError("E_pre requires a complete u_M")
    metadata: dict[str, Any] = {"interface": "system_pre", "composition": ["aligned_model", "target", "uncertainty", "reduction"]}
    if reduction is not None:
        metadata["reduction"] = reduction.__dict__
    return ExplanationObject(
        terms=set(aligned_model.terms) | set(target.terms), representation=target.representation,
        rules=list(aligned_model.rules) + list(target.rules),
        activations={**aligned_model.activations, **target.activations}, uncertainty=uncertainty.u_m,
        trace=target.trace, reduction_loss=reduction.delta if reduction is not None else 0.0, metadata=metadata,
    )


@dataclass(frozen=True)
class SystemRisk:
    rho: float | None
    partial_risk_score: float | None
    status: str
    components: dict[str, float | None]
    weights: dict[str, float]
    action: str
    candidate_action: str
    critical_override: bool


def compute_strict_rho(*, rho_p: float | None, u_m: float | None, i_pre: float | None, delta: float | None, chi_r: float | None, weights: Mapping[str, float], thresholds: Mapping[str, float], critical: int) -> SystemRisk:
    components = {"rho_p": rho_p, "u_M": u_m, "one_minus_I_pre": None if i_pre is None else 1.0 - i_pre, "Delta": delta, "chi_R": chi_r}
    expected = {"rho_p": "w_p", "u_M": "w_u", "one_minus_I_pre": "w_I", "Delta": "w_Delta", "chi_R": "w_R"}
    mapped = {key: float(weights[weight]) for key, weight in expected.items()}
    missing = [key for key, value in components.items() if value is None]
    available_weight = sum(mapped[key] for key in components if components[key] is not None)
    available = {key: float(value) for key, value in components.items() if value is not None}
    partial = None if available_weight == 0 else sum(mapped[key] * _clip01(value) for key, value in available.items()) / available_weight
    if missing:
        return SystemRisk(
            rho=None,
            partial_risk_score=partial,
            status="incomplete",
            components=components,
            weights=mapped,
            action="block" if int(critical) == 1 else "review",
            candidate_action="review",
            critical_override=int(critical) == 1,
        )
    if abs(sum(mapped.values()) - 1.0) > 1e-9:
        raise ValueError("P19 rho weights must sum to one")
    complete_components = {key: float(value) for key, value in components.items() if value is not None}
    rho = sum(mapped[key] * _clip01(value) for key, value in complete_components.items())
    if rho < float(thresholds["theta_1"]):
        candidate_action = "accept"
    elif rho < float(thresholds["theta_2"]):
        candidate_action = "lower_confidence"
    elif rho < float(thresholds["theta_3"]):
        candidate_action = "review"
    else:
        candidate_action = "block"
    critical_override = int(critical) == 1
    return SystemRisk(
        rho=rho,
        partial_risk_score=None,
        status="complete",
        components=components,
        weights=mapped,
        action="block" if critical_override else candidate_action,
        candidate_action=candidate_action,
        critical_override=critical_override,
    )


def interpretability_pre(explanation_pre: ExplanationObject, plan: ExplainPlan) -> float:
    return float(compute_interpretability_index(explanation_pre, plan.lambda_))
