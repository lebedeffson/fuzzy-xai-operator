from __future__ import annotations

from .common import BaselineResult, changed, missing


RULES = {
    "artifact_sha256": ("artifact_integrity", "hash_corruption", "canonical_artifact"),
    "artifact_uri": ("artifact_integrity", "missing_artifact", "artifact_store"),
    "model_version": ("artifact_integrity", "version_mismatch", "model"),
    "explainer_version": ("artifact_integrity", "version_mismatch", "explainer"),
    "model_family": ("semantic_compatibility", "model_explainer_mismatch", "model"),
    "explainer_model_family": ("semantic_compatibility", "model_explainer_mismatch", "explainer"),
    "preprocessing_signature": ("semantic_compatibility", "preprocessing_mismatch", "preprocessor"),
    "dictionary_version": ("semantic_compatibility", "dictionary_mismatch", "dictionary"),
    "reference_population": ("reference_context", "wrong_reference_population", "reference_context"),
    "calibration_version": ("reference_context", "stale_calibration", "calibrator"),
    "deployment_context": ("reference_context", "deployment_context_mismatch", "deployment_context"),
    "source_uri": ("provenance", "missing_source", "provenance_source"),
    "dependency_digest": ("provenance", "broken_dependency", "dependency_graph"),
    "artifact_model_id": ("provenance", "cross_model_artifact_mix", "artifact_store"),
    "reduction_loss": ("reduction", "excessive_information_loss", "reducer"),
    "projection_type": ("reduction", "unsupported_projection", "reducer"),
    "canonical_source_id": ("reduction", "lost_canonical_link", "canonical_artifact"),
}


class IndependentRulesBaseline:
    name = "independent_if_else"

    def diagnose(self, route: object) -> BaselineResult:
        absent = missing(route)
        differences = tuple(field for field in changed(route) if field in RULES)
        active = tuple(dict.fromkeys(absent + differences))
        if not active:
            return BaselineResult("valid", confidence=1.0)
        matches = [RULES[field] for field in active if field in RULES]
        family = matches[0][0] if matches and all(item[0] == matches[0][0] for item in matches) else None
        leaf = matches[0][1] if matches and all(item[1] == matches[0][1] for item in matches) else None
        sources = tuple(dict.fromkeys(item[2] for item in matches))
        return BaselineResult(
            "insufficient_evidence" if absent else "invalid",
            family,
            leaf,
            sources,
            active,
            active,
            unknown=not bool(matches),
            abstained=leaf is None,
            confidence=1.0 if leaf else 0.5,
        )
