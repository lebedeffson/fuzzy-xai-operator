from __future__ import annotations

import random
from dataclasses import dataclass, replace
from typing import Any

from fuzzyxai.audit_h10.diagnostic_cut import DiagnosticCutSolver
from fuzzyxai.audit_h10.models import RouteObservation
from fuzzyxai.audit_h10.taxonomy import SPEC_BY_LEAF


@dataclass(frozen=True)
class MutationTruth:
    case_id: str
    route_status: str
    parent_families: tuple[str, ...]
    leaf_types: tuple[str, ...]
    source_nodes: tuple[str, ...]
    diagnostic_cut: tuple[str, ...]
    repair_set: tuple[str, ...]
    unknown: bool
    insufficient_evidence: bool
    severity: str
    composite: bool


def _value(field: str, original: Any, severity: str) -> Any:
    level = {"subtle": 1, "moderate": 2, "severe": 3}[severity]
    if field in {"artifact_uri", "source_uri", "canonical_source_id"} and severity == "severe":
        return None
    if field == "calibration_age_days":
        return {1: 35.0, 2: 90.0, 3: 365.0}[level]
    if field == "reduction_loss":
        return {1: 0.11, 2: 0.35, 3: 0.95}[level]
    if field == "artifact_sha256":
        keep = {1: 60, 2: 32, 3: 0}[level]
        return str(original)[:keep] + ("f" * (64 - keep))
    if isinstance(original, str):
        if level == 1:
            return original.rsplit("v", 1)[0] + "v0" if "v" in original else original + ":near"
        return f"mutated:{level}:{original}"
    return None if level == 3 else f"mutated:{level}"


def mutate_route(
    route: RouteObservation,
    leaves: tuple[str, ...],
    severity: str,
    *,
    unknown: bool = False,
    insufficient: bool = False,
) -> tuple[RouteObservation, MutationTruth]:
    observed = dict(route.observed)
    affected_fields: list[str] = []
    sources: list[str] = []
    parents: list[str] = []
    for leaf in leaves:
        spec = SPEC_BY_LEAF[leaf]
        parents.append(spec.parent)
        sources.extend(spec.source_nodes)
        fields = spec.fields if severity == "severe" else spec.fields[:1]
        for field in fields:
            affected_fields.append(field)
            observed[field] = _value(field, route.expected.get(field), severity)
    if insufficient:
        field = next((field for field in affected_fields if field in route.mandatory_fields), "source_uri")
        observed[field] = None
    mutated = replace(route, observed=observed)
    affected = set(affected_fields)
    invalid_paths = tuple(frozenset(node for node in path if node in affected) for path in route.dependency_paths)
    invalid_paths = tuple(path for path in invalid_paths if path) or tuple(frozenset((field,)) for field in affected_fields)
    cut = DiagnosticCutSolver().solve(invalid_paths, route.repair_costs).cut_nodes
    case_id = f"{route.route_id}:{'+'.join(leaves)}:{severity}:{int(unknown)}:{int(insufficient)}"
    truth = MutationTruth(
        case_id,
        "insufficient_evidence" if insufficient else "invalid",
        tuple(dict.fromkeys(parents)),
        leaves,
        tuple(dict.fromkeys(sources)),
        cut,
        cut,
        unknown,
        insufficient,
        severity,
        len(leaves) > 1,
    )
    return mutated, truth


def make_cases(
    routes: list[RouteObservation],
    *,
    seed: int,
    known_leaves: tuple[str, ...],
    held_out_leaves: tuple[str, ...],
    include_valid: bool = True,
) -> list[tuple[RouteObservation, MutationTruth]]:
    rng = random.Random(seed)
    cases: list[tuple[RouteObservation, MutationTruth]] = []
    severities = ("subtle", "moderate", "severe")
    for index, route in enumerate(routes):
        selector = index % 10
        if include_valid and selector == 0:
            truth = MutationTruth(f"{route.route_id}:valid", "valid", (), (), (), (), (), False, False, "none", False)
            cases.append((route, truth))
            continue
        unknown = selector in {7, 8} and bool(held_out_leaves)
        pool = held_out_leaves if unknown else known_leaves
        leaf = pool[rng.randrange(len(pool))]
        leaves = (leaf,)
        if selector in {5, 8}:
            second_pool = known_leaves if unknown else pool
            second = second_pool[rng.randrange(len(second_pool))]
            if second != leaf:
                leaves += (second,)
        insufficient = selector == 9
        severity = severities[(index // 3) % len(severities)]
        cases.append(mutate_route(route, leaves, severity, unknown=unknown, insufficient=insufficient))
    return cases
