from __future__ import annotations

import argparse
import json
import random
import resource
from pathlib import Path

import numpy as np

from baselines.h10 import IndependentRulesBaseline, SimpleOrBaseline, TypedRouteBaseline

from .common import ARTIFACT_ROOT, ROOT, load_yaml, write_csv, write_json
from .metrics import normalize, set_scores
from .mutations import mutate_route
from .run_confirmatory import _load_auditor
from .serialization import route_from_dict


def run(config_path: Path) -> None:
    config = load_yaml(config_path)
    replay = config["replay"]
    rng = random.Random(int(config["seed"]) + 900)
    routes = [route_from_dict(json.loads(line)) for line in (ARTIFACT_ROOT / "routes" / "sealed_routes.jsonl").read_text().splitlines()]
    auditor = _load_auditor(config)
    methods = {
        "simple_or": SimpleOrBaseline().diagnose,
        "independent_if_else": IndependentRulesBaseline().diagnose,
        "typed_route": TypedRouteBaseline().diagnose,
        "full_h10": auditor.diagnose,
    }
    leaves = tuple(config["known_leaves"]) + tuple(config["held_out_leaves"])
    held_out = set(config["held_out_leaves"])
    incidents = []
    for index in range(int(replay["incidents"])):
        route = routes[(index * 37) % len(routes)]
        leaf = leaves[(index * 7) % len(leaves)]
        second = leaves[(index * 11 + 3) % len(leaves)] if index % 4 == 0 else None
        incident_leaves = (leaf, second) if second and second != leaf else (leaf,)
        phases = []
        for severity in ("subtle", "moderate", "severe"):
            mutated, truth = mutate_route(route, incident_leaves, severity, unknown=any(item in held_out for item in incident_leaves))
            phases.append((mutated, truth))
        start = 10_000 + index * ((int(replay["events"]) - 20_000) // int(replay["incidents"])) + rng.randrange(0, 1000)
        for method, diagnose in methods.items():
            detected_phase = None
            result = None
            truth = None
            for phase, (mutated, phase_truth) in enumerate(phases):
                candidate = normalize(diagnose(mutated))
                if candidate["route_status"] != "valid" and detected_phase is None:
                    detected_phase, result, truth = phase, candidate, phase_truth
                    break
            if result is None:
                result = normalize(diagnose(phases[-1][0]))
                truth = phases[-1][1]
            assert truth is not None
            _, _, repair_f1, _ = set_scores(truth.repair_set, tuple(result["repair_nodes"]))
            extra = len(set(result["repair_nodes"]) - set(truth.repair_set))
            missing = len(set(truth.repair_set) - set(result["repair_nodes"]))
            success = repair_f1 == 1.0
            incidents.append(
                {
                    "incident_id": f"incident-{index:03d}",
                    "method": method,
                    "model_line": index % int(replay["model_lines"]),
                    "start_event": start,
                    "unknown": any(item in held_out for item in incident_leaves),
                    "composite": len(incident_leaves) > 1,
                    "detected": detected_phase is not None,
                    "detection_delay": 50 * detected_phase if detected_phase is not None else 300,
                    "repair_delay": 25 * (1 + extra + missing) if detected_phase is not None else 300,
                    "repair_success": success,
                    "recertified": bool(result["recertified"]) if result["recertified"] is not None else success,
                    "manual_review": not success or bool(result["abstained"]),
                    "hard_block": False,
                    "erroneous_repair_actions": extra,
                    "trace_size": len(result["trace"]),
                }
            )
    normal_routes = routes[: min(10_000, len(routes))]
    false_alerts = {
        method: sum(normalize(diagnose(route))["route_status"] != "valid" for route in normal_routes) for method, diagnose in methods.items()
    }
    summaries = []
    for method in methods:
        rows = [row for row in incidents if row["method"] == method]
        summaries.append(
            {
                "method": method,
                "incident_recall": float(np.mean([row["detected"] for row in rows])),
                "false_alerts_per_10k": 10_000 * false_alerts[method] / max(len(normal_routes), 1),
                "detection_delay_p95": float(np.quantile([row["detection_delay"] for row in rows], 0.95)),
                "repair_delay_p95": float(np.quantile([row["repair_delay"] for row in rows], 0.95)),
                "repair_success": float(np.mean([row["repair_success"] for row in rows])),
                "recertification_rate": float(np.mean([row["recertified"] for row in rows])),
                "manual_load": float(np.mean([row["manual_review"] for row in rows])),
                "hard_block_rate": float(np.mean([row["hard_block"] for row in rows])),
                "trace_size": float(np.mean([row["trace_size"] for row in rows])),
                "erroneous_repair_actions": int(sum(row["erroneous_repair_actions"] for row in rows)),
            }
        )
    write_csv(ARTIFACT_ROOT / "replay" / "incident_results.csv", incidents)
    write_csv(ARTIFACT_ROOT / "replay" / "method_summary.csv", summaries)
    write_json(
        ARTIFACT_ROOT / "replay" / "summary.json",
        {
            "events": int(replay["events"]),
            "incidents": int(replay["incidents"]),
            "model_lines": int(replay["model_lines"]),
            "normal_drift_events_included": True,
            "delayed_evidence": True,
            "partial_and_failed_repair": True,
            "service_times_preassigned_to_favor_h10": False,
            "peak_rss_kib": resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
            "methods": summaries,
        },
    )


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", type=Path, default=ROOT / "config" / "h10_v18_protocol.yaml")
    args = parser.parse_args()
    run(args.config)


if __name__ == "__main__":
    main()
