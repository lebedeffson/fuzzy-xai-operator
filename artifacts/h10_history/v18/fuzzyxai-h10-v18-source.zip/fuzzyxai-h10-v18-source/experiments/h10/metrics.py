from __future__ import annotations

from dataclasses import asdict
from time import perf_counter
from typing import Any, Callable

import numpy as np
from sklearn.metrics import average_precision_score, roc_auc_score

from baselines.h10.common import BaselineResult
from fuzzyxai.audit_h10.models import AuditDiagnosis

from .mutations import MutationTruth


def set_scores(expected: tuple[str, ...], predicted: tuple[str, ...]) -> tuple[float, float, float, float]:
    left, right = set(expected), set(predicted)
    if not left and not right:
        return 1.0, 1.0, 1.0, 1.0
    precision = len(left & right) / len(right) if right else 0.0
    recall = len(left & right) / len(left) if left else float(not right)
    f1 = 2 * precision * recall / (precision + recall) if precision + recall else 0.0
    union = len(left | right)
    return precision, recall, f1, len(left & right) / union if union else 1.0


def normalize(value: AuditDiagnosis | BaselineResult) -> dict[str, Any]:
    if isinstance(value, AuditDiagnosis):
        return {
            "route_status": value.route_status,
            "parent_family": value.fault.parent_family,
            "leaf_type": value.fault.leaf_type,
            "source_nodes": value.source_nodes,
            "cut_nodes": value.diagnostic_cut.cut_nodes,
            "repair_nodes": tuple(item.target for item in value.repair_set),
            "unknown": value.fault.unknown,
            "abstained": value.fault.abstained_at_leaf,
            "confidence": value.fault.leaf_confidence,
            "anomaly_score": float(value.details.get("anomaly_score", 0.0)),
            "recertified": value.recertified,
            "trace": value.trace,
            "cut_cost": value.diagnostic_cut.total_cost,
            "cut_optimal": value.diagnostic_cut.optimal,
            "cut_runtime_ms": value.diagnostic_cut.runtime_ms,
        }
    row = asdict(value)
    row.update({"recertified": None, "trace": b"", "cut_cost": 0.0, "cut_optimal": False, "cut_runtime_ms": 0.0})
    return row


def evaluate_method(
    name: str,
    diagnose: Callable[[Any], AuditDiagnosis | BaselineResult],
    cases: list[tuple[Any, MutationTruth]],
) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for route, truth in cases:
        started = perf_counter()
        result = normalize(diagnose(route))
        latency_ms = (perf_counter() - started) * 1000.0
        source_precision, source_recall, source_f1, _ = set_scores(truth.source_nodes, tuple(result["source_nodes"]))
        repair_precision, repair_recall, repair_f1, _ = set_scores(truth.repair_set, tuple(result["repair_nodes"]))
        _, _, cut_f1, cut_jaccard = set_scores(truth.diagnostic_cut, tuple(result["cut_nodes"]))
        expected_cost = sum(route.repair_costs.get(node, 1.0) for node in truth.diagnostic_cut)
        cut_cost = float(result["cut_cost"] or sum(route.repair_costs.get(node, 1.0) for node in result["cut_nodes"]))
        rows.append(
            {
                "case_id": truth.case_id,
                "dataset": route.dataset_id,
                "modality": route.modality,
                "method": name,
                "truth_status": truth.route_status,
                "truth_parent": truth.parent_families[0] if len(truth.parent_families) == 1 else None,
                "truth_leaf": truth.leaf_types[0] if len(truth.leaf_types) == 1 else None,
                "truth_unknown": truth.unknown,
                "severity": truth.severity,
                "composite": truth.composite,
                "predicted_status": result["route_status"],
                "predicted_parent": result["parent_family"],
                "predicted_leaf": result["leaf_type"],
                "predicted_unknown": result["unknown"],
                "abstained": result["abstained"],
                "known_confidence": result["confidence"],
                "anomaly_score": result["anomaly_score"],
                "source_precision": source_precision,
                "source_recall": source_recall,
                "source_f1": source_f1,
                "repair_precision": repair_precision,
                "repair_recall": repair_recall,
                "repair_f1": repair_f1,
                "cut_exact": float(set(truth.diagnostic_cut) == set(result["cut_nodes"])),
                "cut_f1": cut_f1,
                "cut_jaccard": cut_jaccard,
                "cut_cost_ratio": cut_cost / expected_cost if expected_cost else 1.0,
                "cut_extra_nodes": len(set(result["cut_nodes"]) - set(truth.diagnostic_cut)),
                "cut_runtime_ms": result["cut_runtime_ms"],
                "cut_optimal": result["cut_optimal"],
                "recertified": result["recertified"],
                "false_certification": float(truth.route_status != "valid" and result["route_status"] == "valid"),
                "false_block": 0.0,
                "parent_correct": float(result["parent_family"] == (truth.parent_families[0] if len(truth.parent_families) == 1 else None)),
                "leaf_correct": float(result["leaf_type"] == (truth.leaf_types[0] if len(truth.leaf_types) == 1 else None)),
                "unknown_correct": float(bool(result["unknown"]) == truth.unknown),
                "diagnostic_latency_ms": latency_ms,
                "trace_size": len(result["trace"]),
            }
        )
    return rows


def summarize(rows: list[dict[str, Any]]) -> dict[str, float]:
    metrics = (
        "source_f1",
        "repair_f1",
        "false_certification",
        "false_block",
        "parent_correct",
        "leaf_correct",
        "unknown_correct",
        "cut_exact",
        "cut_jaccard",
        "cut_cost_ratio",
        "diagnostic_latency_ms",
        "trace_size",
    )
    summary = {metric: float(np.mean([float(row[metric]) for row in rows])) for metric in metrics}
    y_true = np.asarray([float(row["truth_unknown"]) for row in rows])
    anomaly = np.asarray([float(row["anomaly_score"]) for row in rows])
    if len(np.unique(y_true)) == 2:
        summary["unknown_auroc"] = float(roc_auc_score(y_true, anomaly))
        summary["unknown_auprc"] = float(average_precision_score(y_true, anomaly))
    else:
        summary["unknown_auroc"] = float("nan")
        summary["unknown_auprc"] = float("nan")
    return summary
