from __future__ import annotations

import csv
import hashlib
import io
import json
import os
import urllib.request
import zipfile
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Iterable

import yaml


ROOT = Path(__file__).resolve().parents[2]
DATA_ROOT = ROOT / "data" / "h10"
ARTIFACT_ROOT = ROOT / "artifacts" / "h10_v18"
PRIVATE_ROOT = ROOT / ".h10_private"


@dataclass(frozen=True)
class DatasetSpec:
    dataset_id: str
    modality: str
    urls: tuple[str, ...]
    license: str
    source: str


DATASETS = (
    DatasetSpec(
        "uci_raisin",
        "tabular",
        ("https://archive.ics.uci.edu/static/public/850/raisin.zip",),
        "CC BY 4.0",
        "UCI Machine Learning Repository",
    ),
    DatasetSpec(
        "uci_sentiment_labelled_sentences",
        "text",
        ("https://archive.ics.uci.edu/static/public/331/sentiment+labelled+sentences.zip",),
        "CC BY 4.0",
        "UCI Machine Learning Repository",
    ),
    DatasetSpec(
        "ucr_forda",
        "time_series",
        (
            "https://raw.githubusercontent.com/hfawaz/cd-diagram/master/FordA/FordA_TRAIN.tsv",
            "https://raw.githubusercontent.com/hfawaz/cd-diagram/master/FordA/FordA_TEST.tsv",
        ),
        "UCR Archive research dataset; redistribution excluded from bundles",
        "UCR Time Series Classification Archive mirror",
    ),
)


def sha256_bytes(value: bytes) -> str:
    return hashlib.sha256(value).hexdigest()


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def write_json(path: Path, payload: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2, sort_keys=True) + "\n", encoding="utf-8")


def read_json(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))


def load_yaml(path: Path) -> dict[str, Any]:
    return yaml.safe_load(path.read_text(encoding="utf-8"))


def download(url: str, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists():
        return
    request = urllib.request.Request(url, headers={"User-Agent": "FuzzyXAI-H10/1.0"})
    with urllib.request.urlopen(request, timeout=120) as response:
        path.write_bytes(response.read())


def _raisin_objects(path: Path) -> list[bytes]:
    outer = zipfile.ZipFile(path)
    inner = zipfile.ZipFile(io.BytesIO(outer.read("Raisin_Dataset.zip")))
    arff = inner.read("Raisin_Dataset/Raisin_Dataset.arff").decode("utf-8", errors="replace")
    data = arff.split("@data", 1)[1]
    return [line.strip().encode("utf-8") for line in data.splitlines() if line.strip() and not line.startswith("%")]


def _sentiment_objects(path: Path) -> list[bytes]:
    rows: list[bytes] = []
    with zipfile.ZipFile(path) as archive:
        for name in sorted(item for item in archive.namelist() if item.endswith("_labelled.txt") and not item.startswith("__MACOSX")):
            rows.extend(line.strip() for line in archive.read(name).splitlines() if line.strip())
    return rows


def _forda_objects(paths: Iterable[Path]) -> list[bytes]:
    rows: list[bytes] = []
    for path in paths:
        with path.open("rb") as handle:
            rows.extend(line.strip() for line in handle if line.strip())
    return rows


def prepare_datasets() -> list[dict[str, Any]]:
    records: list[dict[str, Any]] = []
    for spec in DATASETS:
        local_paths = []
        for index, url in enumerate(spec.urls):
            suffix = Path(url).name or f"source-{index}"
            path = DATA_ROOT / spec.dataset_id / "raw" / suffix
            download(url, path)
            local_paths.append(path)
        if spec.dataset_id == "uci_raisin":
            objects = _raisin_objects(local_paths[0])
        elif spec.dataset_id == "uci_sentiment_labelled_sentences":
            objects = _sentiment_objects(local_paths[0])
        else:
            objects = _forda_objects(local_paths)
        identities = sorted({sha256_bytes(row) for row in objects})
        split_rows = []
        for object_id in identities:
            bucket = int(object_id[:8], 16) % 100
            split = "train" if bucket < 60 else "development" if bucket < 80 else "sealed_test"
            split_rows.append({"object_id": object_id, "split": split})
        split_path = DATA_ROOT / spec.dataset_id / "manifests" / "split_manifest.json"
        write_json(split_path, split_rows)
        counts = {split: sum(row["split"] == split for row in split_rows) for split in ("train", "development", "sealed_test")}
        records.append(
            {
                **asdict(spec),
                "urls": list(spec.urls),
                "source_files": [{"name": path.name, "sha256": sha256_file(path), "bytes": path.stat().st_size} for path in local_paths],
                "objects": len(identities),
                "split_counts": counts,
                "split_manifest_sha256": sha256_file(split_path),
            }
        )
    write_json(ARTIFACT_ROOT / "data" / "dataset_manifest.json", records)
    return records


def load_identities(dataset_id: str, split: str) -> list[str]:
    rows = read_json(DATA_ROOT / dataset_id / "manifests" / "split_manifest.json")
    return [row["object_id"] for row in rows if row["split"] == split]


def git_commit() -> str:
    import subprocess

    return subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=ROOT, text=True).strip()


def environment_manifest() -> dict[str, Any]:
    import platform
    import sys

    return {
        "python": sys.version,
        "platform": platform.platform(),
        "processor": platform.processor(),
        "cpu_count": os.cpu_count(),
        "commit": git_commit(),
    }


def write_csv(path: Path, rows: list[dict[str, Any]], fieldnames: list[str] | None = None) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    names = fieldnames or sorted({key for row in rows for key in row})
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=names, lineterminator="\n")
        writer.writeheader()
        writer.writerows(rows)
