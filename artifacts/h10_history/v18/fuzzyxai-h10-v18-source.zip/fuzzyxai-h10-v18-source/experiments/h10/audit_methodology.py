from __future__ import annotations


from .common import ARTIFACT_ROOT, ROOT, read_json, write_json


def audit() -> dict:
    mutation_source = (ROOT / "experiments" / "h10" / "mutations.py").read_text(encoding="utf-8")
    localization_source = (ROOT / "framework" / "fuzzyxai" / "fuzzyxai" / "audit_h10" / "source_localizer.py").read_text(encoding="utf-8")
    replay_source = (ROOT / "experiments" / "h10" / "run_replay.py").read_text(encoding="utf-8")
    findings = {
        "cut_truth_reuses_evaluated_solver": "DiagnosticCutSolver" in mutation_source,
        "source_truth_and_localizer_share_taxonomy_mapping": "SPEC_BY_LEAF" in mutation_source and "FIELD_TO_SPECS" in localization_source,
        "replay_normal_stream_uses_mutated_sealed_routes": "normal_routes = routes" in replay_source,
    }
    invalid = any(findings.values())
    report = {
        "status": "INVALID_FOR_COMPARATIVE_CONFIRMATORY_CLAIMS" if invalid else "PASS",
        "findings": findings,
        "sealed_scoring_repeated": False,
        "post_open_tuning": False,
        "affected_claims": ["H10-L", "H10-C", "H10-R"] if invalid else [],
        "unaffected_claims": ["H10-T"] if invalid else ["H10-L", "H10-C", "H10-R", "H10-T"],
        "replay_status": "invalid_due_to_mutated_normal_stream" if findings["replay_normal_stream_uses_mutated_sealed_routes"] else "valid",
        "required_next_step": "fresh protocol and sealed data with an independent adjudication oracle; do not rescore v18",
    }
    write_json(ARTIFACT_ROOT / "closure" / "confirmatory_methodology_audit.json", report)
    write_json(
        ARTIFACT_ROOT / "opening" / "confirmatory_invalid_marker.json",
        {
            "status": report["status"],
            "reason": "ground-truth/evaluator coupling discovered during closure audit",
            "old_outputs_preserved": True,
            "repeat_scoring_forbidden": True,
        },
    )
    raw_registry = read_json(ARTIFACT_ROOT / "closure" / "h10_v18_claim_registry_raw_pre_methodology_audit.json")
    raw_registry["claims"] = {
        "H10-L": "invalid_not_evaluated_independently",
        "H10-C": "invalid_not_evaluated_independently",
        "H10-R": "invalid_not_evaluated_independently",
        "H10-U": "descriptive_only_no_confirmatory_claim",
        "H10-T": "supported_byte_identical_trace_only",
    }
    raw_registry["scientific_release_allowed"] = False
    raw_registry["methodology_audit"] = report
    raw_registry["manual_positive_override"] = False
    tests = read_json(ARTIFACT_ROOT / "confirmatory" / "statistical_tests_raw_pre_methodology_audit.json")
    for test in tests:
        test["status_before_methodology_audit"] = test["status"]
        test["status"] = "invalid_not_evaluated_independently"
    raw_registry["primary_tests"] = tests
    write_json(ARTIFACT_ROOT / "closure" / "h10_v18_claim_registry.json", raw_registry)
    write_json(ARTIFACT_ROOT / "confirmatory" / "statistical_tests.json", tests)
    return report


if __name__ == "__main__":
    audit()
