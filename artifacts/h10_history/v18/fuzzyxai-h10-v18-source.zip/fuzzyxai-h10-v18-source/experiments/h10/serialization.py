from __future__ import annotations

from dataclasses import asdict
from typing import Any

from fuzzyxai.audit_h10.models import RouteObservation

from .mutations import MutationTruth


def route_to_dict(route: RouteObservation) -> dict[str, Any]:
    return asdict(route)


def route_from_dict(payload: dict[str, Any]) -> RouteObservation:
    return RouteObservation(
        route_id=payload["route_id"],
        dataset_id=payload["dataset_id"],
        modality=payload["modality"],
        object_id=payload["object_id"],
        expected=payload["expected"],
        observed=payload["observed"],
        mandatory_fields=tuple(payload["mandatory_fields"]),
        dependency_paths=tuple(tuple(path) for path in payload["dependency_paths"]),
        repair_costs={key: float(value) for key, value in payload["repair_costs"].items()},
    )


def truth_to_dict(truth: MutationTruth) -> dict[str, Any]:
    return asdict(truth)


def truth_from_dict(payload: dict[str, Any]) -> MutationTruth:
    return MutationTruth(
        case_id=payload["case_id"],
        route_status=payload["route_status"],
        parent_families=tuple(payload["parent_families"]),
        leaf_types=tuple(payload["leaf_types"]),
        source_nodes=tuple(payload["source_nodes"]),
        diagnostic_cut=tuple(payload["diagnostic_cut"]),
        repair_set=tuple(payload["repair_set"]),
        unknown=bool(payload["unknown"]),
        insufficient_evidence=bool(payload["insufficient_evidence"]),
        severity=payload["severity"],
        composite=bool(payload["composite"]),
    )
