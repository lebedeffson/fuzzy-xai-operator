from __future__ import annotations

from .models import RouteObservation
from .route_validity import ValidityResult
from .taxonomy import FIELD_TO_SPECS


class SourceLocalizer:
    def localize(self, route: RouteObservation, validity: ValidityResult) -> tuple[str, ...]:
        fields = validity.missing_fields + validity.mismatched_fields
        candidates: list[str] = []
        for field in fields:
            for spec in FIELD_TO_SPECS.get(field, ()):
                candidates.extend(spec.source_nodes)
        return tuple(dict.fromkeys(candidates))
