from __future__ import annotations

from .models import DiagnosticCutResult, RepairAction
from .taxonomy import FIELD_TO_SPECS


class RepairSetPlanner:
    def plan(self, cut: DiagnosticCutResult) -> tuple[RepairAction, ...]:
        actions: list[RepairAction] = []
        for node in cut.cut_nodes:
            specs = FIELD_TO_SPECS.get(node, ())
            operation = specs[0].repair_action if specs else f"restore_registered_value:{node}"
            actions.append(
                RepairAction(
                    target=node,
                    action=operation,
                    expected_effect=f"restore_contract:{node}",
                    preconditions=(f"registered_value_available:{node}",),
                )
            )
        return tuple(actions)
