from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class FaultSpec:
    parent: str
    leaf: str
    fields: tuple[str, ...]
    source_nodes: tuple[str, ...]
    repair_action: str


FAULT_SPECS = (
    FaultSpec("artifact_integrity", "hash_corruption", ("artifact_sha256",), ("canonical_artifact",), "restore_verified_artifact"),
    FaultSpec("artifact_integrity", "missing_artifact", ("artifact_uri",), ("artifact_store",), "reload_missing_artifact"),
    FaultSpec("artifact_integrity", "version_mismatch", ("model_version", "explainer_version"), ("model", "explainer"), "align_component_versions"),
    FaultSpec("semantic_compatibility", "model_explainer_mismatch", ("model_family", "explainer_model_family"), ("model", "explainer"), "load_compatible_explainer"),
    FaultSpec("semantic_compatibility", "preprocessing_mismatch", ("preprocessing_signature",), ("preprocessor",), "restore_registered_preprocessing"),
    FaultSpec("semantic_compatibility", "dictionary_mismatch", ("dictionary_version",), ("dictionary",), "restore_registered_dictionary"),
    FaultSpec("reference_context", "wrong_reference_population", ("reference_population",), ("reference_context",), "restore_reference_population"),
    FaultSpec("reference_context", "stale_calibration", ("calibration_version", "calibration_age_days"), ("calibrator",), "refresh_calibration"),
    FaultSpec("reference_context", "deployment_context_mismatch", ("deployment_context",), ("deployment_context",), "restore_deployment_context"),
    FaultSpec("provenance", "missing_source", ("source_uri",), ("provenance_source",), "restore_source_reference"),
    FaultSpec("provenance", "broken_dependency", ("dependency_digest",), ("dependency_graph",), "rebuild_dependency_link"),
    FaultSpec("provenance", "cross_model_artifact_mix", ("artifact_model_id", "model_id"), ("artifact_store", "model"), "replace_cross_model_artifact"),
    FaultSpec("reduction", "excessive_information_loss", ("reduction_loss",), ("reducer",), "select_loss_bounded_projection"),
    FaultSpec("reduction", "unsupported_projection", ("projection_type",), ("reducer",), "select_supported_projection"),
    FaultSpec("reduction", "lost_canonical_link", ("canonical_source_id",), ("reducer", "canonical_artifact"), "restore_canonical_link"),
)

FAULT_TAXONOMY: dict[str, tuple[str, ...]] = {}
for _spec in FAULT_SPECS:
    FAULT_TAXONOMY.setdefault(_spec.parent, ())
    FAULT_TAXONOMY[_spec.parent] += (_spec.leaf,)

SPEC_BY_LEAF = {spec.leaf: spec for spec in FAULT_SPECS}
FIELD_TO_SPECS = {field: tuple(spec for spec in FAULT_SPECS if field in spec.fields) for spec in FAULT_SPECS for field in spec.fields}
