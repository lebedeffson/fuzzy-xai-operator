from __future__ import annotations

from dataclasses import replace

from .models import RepairAction, RouteObservation
from .route_validity import validate_route


def execute_and_recertify(route: RouteObservation, actions: tuple[RepairAction, ...]) -> tuple[RouteObservation, bool]:
    observed = dict(route.observed)
    for action in actions:
        if action.target in route.expected:
            observed[action.target] = route.expected[action.target]
    repaired = replace(route, observed=observed)
    return repaired, validate_route(repaired).status == "valid"
