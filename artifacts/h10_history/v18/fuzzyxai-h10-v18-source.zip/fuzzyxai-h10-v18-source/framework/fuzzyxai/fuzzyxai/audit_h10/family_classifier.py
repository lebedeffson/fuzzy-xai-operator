from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from .features import FEATURE_NAMES, extract_feature_dict, softmax, vectorize
from .models import FaultPrediction, RouteObservation
from .taxonomy import SPEC_BY_LEAF


@dataclass
class FaultFamilyClassifier:
    leaf_abstention_threshold: float = 0.60

    def __post_init__(self) -> None:
        self.feature_names = FEATURE_NAMES + ("missing_fraction", "path_disagreement")
        self._centroids: dict[str, np.ndarray] = {}

    def fit(self, samples: list[tuple[RouteObservation, str]]) -> "FaultFamilyClassifier":
        grouped: dict[str, list[np.ndarray]] = {}
        for route, leaf in samples:
            grouped.setdefault(leaf, []).append(vectorize(extract_feature_dict(route), self.feature_names))
        self._centroids = {leaf: np.mean(rows, axis=0) for leaf, rows in grouped.items()}
        return self

    def probabilities(self, route: RouteObservation) -> dict[str, float]:
        if not self._centroids:
            return {}
        value = vectorize(extract_feature_dict(route), self.feature_names)
        leaves = tuple(sorted(self._centroids))
        distances = np.asarray([np.linalg.norm(value - self._centroids[leaf]) for leaf in leaves])
        probabilities = softmax(-2.0 * distances)
        return dict(zip(leaves, (float(item) for item in probabilities), strict=True))

    def predict(self, route: RouteObservation, *, unknown: bool = False) -> FaultPrediction:
        probabilities = self.probabilities(route)
        if unknown or not probabilities:
            return FaultPrediction(None, None, max(probabilities.values(), default=0.0), True, unknown)
        leaf, confidence = max(probabilities.items(), key=lambda item: (item[1], item[0]))
        parent = SPEC_BY_LEAF[leaf].parent
        abstained = confidence < self.leaf_abstention_threshold
        return FaultPrediction(parent, None if abstained else leaf, confidence, abstained, False)
