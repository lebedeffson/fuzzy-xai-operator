# FuzzyXAI Visualization Report

FuzzyXAI visual analytics shows the operator-risk-action trace rather than feature contribution alone.

Canonical visualizations:

1. Operator Route Sankey
2. Gamma-Delta Action Map
3. Risk Waterfall
4. Operator Trace Heatmap
5. Representation Class Atlas
6. Explanation Coverage Curve
7. Action Boundary Plot
8. Proof Consistency Matrix

All PNG and HTML artifacts are rendered from route, operator trace, proof/verifier data, or research CSV files.

```json
{
  "source_commit": "67609a521f6c45d2c6aa85a30024a7f8edb750ca",
  "package_type": "fuzzyxai_visualization_package",
  "visual_idea": "operator-risk-action trace",
  "checks": {
    "single_case_visuals": "PASS",
    "research_visuals": "PASS",
    "png_created": "PASS",
    "html_created": "PASS",
    "cli_visualize": "PASS"
  },
  "canonical_visualizations": [
    "Operator Route Sankey",
    "Gamma-Delta Action Map",
    "Risk Waterfall",
    "Operator Trace Heatmap",
    "Representation Class Atlas",
    "Explanation Coverage Curve",
    "Action Boundary Plot",
    "Proof Consistency Matrix"
  ]
}
```
