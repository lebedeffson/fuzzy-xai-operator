# FuzzyXAI SHAP-like Visualization Report

## Purpose

This package defines a SHAP-like visual refinement for FuzzyXAI. The goal is readability comparable to common explainability figures while preserving FuzzyXAI mathematics. SHAP waterfall plots are additive: a base value and feature contributions are summed to a prediction. FuzzyXAI routes usually do not use additive aggregation. The risk value rho is commonly computed by an aggregation rule such as max(gamma, delta, quality, conflict, interval). Therefore the figures in this package visualize operator risk evidence, dominance and action boundaries rather than cumulative feature contribution.

## Difference from SHAP

SHAP answers how features contributed to a model prediction. FuzzyXAI answers why an explanation received a trust regime such as accept, lower_confidence, audit, defer_to_human or block. A feature attribution can be locally reasonable while the FuzzyXAI route still lowers confidence because explanation coverage is incomplete, input quality is limited, or a conflict component dominates the risk. The visual unit is therefore not a feature, but an operator component: uncertainty, reduction, quality, conflict and interval evidence. The action follows from rho and ExplainPlan thresholds.

## S1 Operator Risk Contribution Summary

This figure is the FuzzyXAI analogue of a SHAP summary bar plot, but it avoids claiming additive contribution. For each risk component it reports mean_value, std_value, dominance_count, dominance_rate, mean_excess_over_warning and max_value. The dominance rate is essential: a component with moderate mean value can still be responsible for critical actions in specific task classes. The CSV used for the plot is included as data/operator_risk_contribution_summary.csv.

## S2 Local Risk Evidence Bridge

This figure replaces the unsafe cumulative waterfall for max aggregation. It shows parallel bars for uncertainty, reduction, quality, conflict and interval evidence, then draws a vertical rho line computed by the aggregation rule. For the default max rule the dominant component is highlighted; no component is visually added to another. If future plans use weighted_sum, a cumulative variant may be introduced, but this package explicitly checks that the max bridge is used for max aggregation.

## S3 Gamma-Delta Action Map v2

The background is generated from the ExplainPlan thresholds and rho=max(gamma, delta), not from decorative rectangles. The accept region is the lower-left square where both gamma and delta are below the accept threshold. The next zones follow max(gamma, delta) ranges. Points are real research validation experiments. Point color shows action_id and marker shape/edge indicates dominant risk component.

## S4 Action Boundary Strip v2

The strip shows rho on a single action scale, distances to neighboring thresholds and the dominant evidence. It answers why the route is not in a neighboring zone: for example, reduction can keep rho above the accept boundary even when uncertainty is not high.

## S5 Compact Operator Trace Heatmap v2

The compact heatmap contains only numeric risk evidence columns. It intentionally excludes long diagnostic and action labels from the numeric matrix. This keeps the chapter figure readable and prevents mixing categorical states with continuous evidence values.

## S6 Representation Class Atlas v2

The atlas maps task_type by perturbation. Color is the majority representation class and the label contains the class and experiment count. This shows where F0, F_int, NAS and F_ML are activated and avoids treating class coverage as a simple binary flag.

## S7 Explanation Coverage Curve

The coverage curve remains part of the visual language because it explains delta directly. Top-k coverage is the visible retained explanation mass; delta is the residual loss. It is included in the broader visual package and the risk bridge uses the same reduction component.

## S8 Proof Consistency Matrix v2

The proof matrix is not SHAP-like, but it is a FuzzyXAI-specific audit figure. It checks artifacts against invariants: source_commit, gamma, delta, rho, diagnostic, action, route_id, sha256 and verifier_status. Green means passed, gray means not applicable and red means failed. This supports reproducibility claims for generated dashboards.

## Mathematical correctness rule

The most important design constraint is that the visual grammar must match the aggregation semantics. If the ExplainPlan or route states that risk is aggregated by max, then a cumulative stacked waterfall is forbidden because it implies a sum. The Local Risk Evidence Bridge therefore presents components as simultaneous evidence bars. The final rho marker is drawn as the aggregation result, and the dominant component is emphasized as the component that determines the max. This is deliberately different from a SHAP waterfall. It is less familiar at first sight, but it is faithful to the operator calculus used by FuzzyXAI. If a future route uses weighted_sum, the renderer can switch to a cumulative plot only when weights are present and the aggregation rule explicitly allows addition.

## Reading the figures together

The figures are meant to be read as a coordinated explanation board. Start with S2 for a single local decision: it identifies the operator evidence and the dominant risk source. Then inspect S4 to see whether rho lies near a boundary. A route can be lower_confidence because it is only slightly above accept, or because it is moving toward audit. S3 then places the same decision in the global gamma-delta decision geometry, where other research experiments can be compared. S1 gives the population-level component summary and indicates whether a component dominates often or merely has a high average. S5 and S6 are chapter-level comparison views, while S8 supports auditability. This order avoids the common mistake of interpreting one figure as a complete explanation.

## Why dominance matters

Mean values alone are not enough for FuzzyXAI. A component may have low mean value across the validation suite but still determine action in a small set of important experiments. For example, quality evidence may be near zero for clean tabular cases and much higher for signal or image perturbations. A mean bar would hide that behavior. Dominance_count and dominance_rate expose when a component actually controls rho under max aggregation. Mean_excess_over_warning adds another view: it shows how far a component crosses a policy threshold when it does become active. Together these statistics are a safer analogue of contribution magnitude.

## Chapter use

For Chapter 4 the recommended primary figures are S2 Local Risk Evidence Bridge, S3 Gamma-Delta Action Map v2, S4 Action Boundary Strip v2, S5 Compact Operator Trace Heatmap v2 and S8 Proof Consistency Matrix v2. S1 is useful for an aggregate research summary, and S6 demonstrates representation-class coverage. The categorical decision heatmap is included for appendix-level inspection because it contains long labels that are better suited to HTML or supplementary figures than to the main dissertation text.

## Validation checks

The package builder verifies that PNG, PDF and SVG files exist for all chapter figures. It verifies that the bridge uses max aggregation rather than cumulative summation. It writes a visual_source_index.json file so the reader can identify the route, trace, audit package and research CSV used to render the figures. It also validates sha256 entries in the manifest while excluding manifest.json itself from the hash list. These checks are small, but they protect the main claim: the figures are generated from FuzzyXAI artifacts, not manually drawn after the fact.

## Separation of numeric and categorical evidence

The refined visual set separates continuous risk evidence from categorical decisions. The compact operator trace heatmap contains numeric columns only: gamma, delta, rho and component values. This makes color intensity mean one thing across the matrix. Representation class, diagnostic state, action and verifier status are categorical and therefore belong in a separate decision heatmap or table. Mixing both types in one heatmap may look compact, but it weakens interpretation because a red numeric risk and a red category label do not necessarily encode the same mathematical quantity. The package keeps the numeric chapter figure concise and leaves the categorical view as supplementary evidence.

## Interpretation limits

These plots should not be read as performance metrics of the underlying machine-learning models. They are route interpretability and governance figures. A high reduction component means that the explanation supplied to the route is incomplete, not that the classifier is inaccurate. A high quality component means that the input or source conditions constrain trust, not that the target class is false. A proof matrix PASS means that the package is internally consistent; it does not certify real-world correctness. This distinction is essential for using the figures in a dissertation without overstating empirical claims.

## Files and Reproducibility

All figures are rendered from real CSV or JSON artifacts. The package includes PNG, PDF and SVG for chapter-ready figures, plus CSV/JSON source data. The manifest excludes itself from sha256 to avoid self-hash instability. The source_commit records the exact code revision used to build this package.

## Limitations

These figures validate operator-risk-action visualization, not external clinical or industrial deployment. The default aggregation shown here is max. Other aggregation functions require matching visualization rules. The package deliberately avoids cumulative waterfall semantics unless the ExplainPlan explicitly uses weighted_sum.

```json
{
  "source_commit": "33bcb6ae55ce66f4af622c5466c262e2447ff321",
  "package_type": "fuzzyxai_shap_like_visualization_package",
  "risk_aggregation": "max",
  "checks": {
    "png_pdf_svg": "PASS",
    "max_evidence_bridge": "PASS",
    "real_csv_json_sources": "PASS",
    "no_cumulative_sum_for_max": "PASS",
    "manifest_self_hash_excluded": "PASS"
  },
  "visualizations": [
    "S1 Operator Risk Contribution Summary",
    "S2 Local Risk Evidence Bridge",
    "S3 Gamma-Delta Action Map v2",
    "S4 Action Boundary Strip v2",
    "S5 Compact Operator Trace Heatmap v2",
    "S6 Representation Class Atlas v2",
    "S7 Explanation Coverage Curve",
    "S8 Proof Consistency Matrix v2"
  ]
}
```
