# Visualization Figures for Chapter 4

This note fixes the chapter-ready SHAP-like visual set for FuzzyXAI. The figures visualize operator evidence, max-risk aggregation, action boundaries and proof consistency.

## Captions

- Figure 4.x -- Operator Risk Contribution Summary. Shows mean component value, dominance rate and warning-threshold excess for uncertainty, reduction, quality, conflict and interval evidence.
- Figure 4.x -- Local Risk Evidence Bridge. Shows risk components as parallel evidence bars and computes `rho=max(...)`; it is not a cumulative waterfall.
- Figure 4.x -- Gamma-Delta Action Map v2. Shows experiments in the `gamma`/`delta` plane with action zones derived from `rho=max(gamma, delta)`.
- Figure 4.x -- Action Boundary Strip v2. Shows `rho`, neighboring action thresholds, distance to adjacent regimes and the dominant evidence component.
- Figure 4.x -- Compact Operator Trace Heatmap v2. Shows only numeric risk evidence values across validation experiments.
- Figure 4.x -- Representation Class Atlas v2. Shows `task_type x perturbation -> representation_class` with experiment counts.
- Figure 4.x -- Explanation Coverage Curve v2. Shows top-k explanation coverage and the residual loss `delta = 1 - coverage`.
- Figure 4.x -- Proof Consistency Matrix v2. Shows agreement of route, trace, proof, dashboard data, verifier and manifest across reproducibility invariants.

## Files

- `assets/operator_risk_contribution_summary.png`
- `assets/local_risk_evidence_bridge.png`
- `assets/gamma_delta_action_map_v2.png`
- `assets/action_boundary_strip_v2.png`
- `assets/compact_operator_trace_heatmap_v2.png`
- `assets/representation_class_atlas_v2.png`
- `assets/explanation_coverage_curve_v2.png`
- `assets/proof_consistency_matrix_v2.png`
