# Project Memory

## FXAI-STRONG-CONFIRMATORY-FORMATIVE

- Date: 2026-07-21
- Branch: `feat/strong-confirmatory-closure`
- Implementation commit: `238194c113fc2f1677730318dfc0ba4d4d4426d5`
- Frozen ancestors: `e34e52f`, `bd48a9c`, `1f5fd77`
- Research phase: formative development
- Confirmatory protocol: blocked
- Stable release: blocked

This milestone implements the fail-closed strong confirmatory program without rewriting or relabeling prior evidence.
The immutable statuses remain `H3-original = not_supported`, `H5-P-original = not_supported`, and
`H6-general = not_supported`. EBM, GAM, RuleFit and rule lists are registered as interpretable predictors rather than
post-hoc explainers; modality-specific post-hoc methods and action policies are separate comparator families.

Measured formative evidence:

- H3-v2 selective observer: formative target not met; no positive policy claim is allowed;
- H5-A controlled route validity: F1 `0.998998998998999`, false certification `0.002`, source localization `0.998`,
  invalid-action recall `0.998`; this is a route-contract result, not an error-prediction claim;
- H6-A semisynthetic planted rules on real tabular features: `24` configurations, detection rate
  `0.8333333333333334`, mean specific effect `0.21666666666666667`; H6-B remains not run;
- H7 stability: image and controlled time-series profiles meet the formative fidelity/stability gate, while tabular
  and cached 20 Newsgroups profiles fail fidelity non-inferiority; the overall H7 formative target is not met;
- H8 controlled component-grid action/representation stability: formative target met;
- H9 cached streaming operator layer: measured to `1,000,000` objects, deterministic repeat PASS, empirical exponent
  `0.9220263168835`; local-explainer cost is explicitly excluded.

The protocol lock deletes/refuses itself until sealed independent dataset manifests and a real formative AI-review
acceptance file exist. Final Chapter 4 generation additionally requires locked confirmatory claims plus real
domain-language, comprehension, and expert-action gates. The current output is a checksummed formative evidence
package and a 17-section chapter shell only; no new strong dissertation conclusion, merge, stable tag, or external
validation claim is allowed.

Next step: complete real formative AI review and seal independent confirmatory datasets. Then lock the protocol once,
run the untouched confirmatory split, and invite independent humans. Do not tune thresholds after test opening.

## FXAI-AI-PRE-REVIEW-FINAL-BLINDING

- Date: 2026-07-20
- Branch: `feat/ai-pre-review-final-closure`
- Frozen invalid-for-scoring prototype: `60ed5697d4d607df59556ea82de63527905f0f4f`
- Leakage-remediation implementation: `c1271db`
- Reviewer-packet hardening commit: `79f80a8`
- Public workflow: `29767282573`, PASS
- Stable release: blocked

The previous 360-case analysis bundle remains a technical prototype but must not be scored: it disclosed outcome,
expected-action and structural answer-key fields. The replacement freezes a reviewer-visible formative input with 240
cases and 720 randomized variants across tabular, image, text and time-series modalities. It includes human-readable
measured features, image regions, text phrases and time intervals, plus direction, normalized magnitude, rank,
stability, source agreement, limitations and complete claim-evidence links.

Validated technical boundary:

- automated leakage and evidence audit: PASS, `240/240` cases, `720/720` variants, claim coverage `1.0`;
- public formative archive: 12 batches and 60 referenced image assets;
- outcome, true label, original stratum, expected action, hidden rupture type, answer-key notes and method identity are
  absent from reviewer-visible records;
- the public ZIP excludes the encrypted scoring key, private paths and all confirmatory records;
- reviewer records contain no internal semantic-block labels; technical audit and claim-registry files are kept out of
  the reviewer ZIP to avoid priming;
- negative tests fail closed for injected outcome, action, stratum and method fields;
- focused test suite: `10 passed`; Ruff and compile checks: PASS;
- confirmatory lock fails closed until at least two real formative runs meet the frozen acceptance contract;
- claim registry remains evidence-first: predecessor negative results are preserved and seven external claims remain
  `open_external`.

Next step: run the 240-case formative AI pre-review using the new public archive. Do not expose the 120 confirmatory
cases, create a protocol lock, invite human reviewers or claim AI-human agreement before real formative results are
imported and accepted. The focused public technical workflow is green; it does not replace the open external gates.

## FXAI-AI-PRE-REVIEW-HUMAN-CONFIRMATION

- Date: 2026-07-20
- Branch: `feat/ai-pre-review-human-confirmation`
- Technical implementation commit: `5c8d0fe`
- Public technical validation commit: `461d267a4a700a4aeff8251ef25f7da539d2bab1`
- Public workflow: `29752785014`, PASS
- Frozen Q1 evidence: `e34e52fb8ae62ee1be043d6d5b26a0c9214a0572`
- Formative observer base: `bd48a9ca3795e2665e0e6a4f1ab4f4e981774c2b`
- Technical status: PASS; AI and human gates open
- Stable release: blocked

This milestone prepares a blind AI pre-review followed by independent human confirmation without treating AI output
as expert evidence. The tracked source snapshot contains 360 unique measured cases: 240 formative and 120
confirmatory, split equally across tabular, image, text and time-series modalities. Three explanation variants per
case are randomized with an out-of-repository HMAC secret; the reversible method map is AES-256 encrypted.

Validated technical boundary:

- master log: 1,080 blind variants;
- review packets: 18 batches, at most 20 cases and 60 variants per batch;
- rubric: R1-R10 plus 12 critical-defect flags;
- AI importer requires complete batches, immutable hashes, exact commit identity and independent `AI_RUN_1..3`;
- confirmatory lock fails closed until a real formative acceptance record exists;
- human packet construction fails closed until protocol lock, three AI runs and score commitment exist;
- human importer requires at least three independently hashed reviewers and rejects AI reviewer records;
- technical DoD after memory/release documentation: 44 PASS, 36 external/public-CI items open;
- focused local tests: 6 passed; new-code Ruff and compile checks: PASS;
- deterministic analysis-input archive: PASS for repeated same-commit builds.
- public focused workflow: PASS on the exact technical validation commit.

Frozen evidence limitation: the Q1 Fashion-MNIST protocol labels every evaluated image class as rare, so the image
modality has no measured `common_class` stratum. The study records this limitation rather than fabricating a class.

Next step: run the formative AI pre-review externally, import the raw JSONL without rewriting it, repair only observed
defects, and lock the confirmatory protocol. Human confirmation remains forbidden until three confirmatory AI runs
are committed. No human-comprehension, domain-approval, expert-validation or stable-release claim is allowed yet.

## Q1 Empirical Remediation

- Date: 2026-07-20
- Branch: `feat/q1-empirical-remediation`
- Frozen predecessor: `cafe403c7d60e36b08f56a5325ba380718a5be35`
- Technical CI commit: `a9ca41ecc9bdfe74024214e5e4b1ed2c3eccefab`
- Public Q1 workflow: `29709914672`
- Candidate status: technical remediation PASS; stable release remains blocked

This independent cycle preserves the earlier E1-E8 negative results and evaluates new preregistered hypotheses
without changing their criteria after measurement. The public workflow passed the focused contracts, four independent
real-modality jobs, a clean Docker reproduction and aggregate evidence verification.

Measured technical evidence:

- real datasets: UCI Covertype `581012`, Fashion-MNIST `70000`, 20 Newsgroups `18846`, and ElectricDevices `16637` objects;
- real benchmark matrix: 16 measured model records and 25 measured explainer records;
- model channels include linear, tree, boosting, CNN, sequence and ONNX execution;
- explainer channels include SHAP, LIME, Anchors, RuleFit, Grad-CAM, Integrated Gradients, and text/time-series masking;
- H1 controlled paired fidelity: 240 pairs, mean delta `0.0`, lower 95% bound `0.0`, non-inferior at margin `-0.02`;
- H2 controlled traceability: `K_trace 0.0 -> 1.0`, missingness F1 `1.0`, false-certification rate `0.0`;
- H3 adaptive cascade controlled cost fraction `0.36666666666666664`, with the preregistered risk-cost criterion met;
- H4 adaptive hierarchy uses FML for `0.5641666666666667` of objects and reduces mean representation complexity by `2.3258333333333336` versus always-FML while meeting non-inferiority;
- H5 structural diagnosis F1 `1.0`, but predictive incremental AUPRC `-0.0005609278151094133`; predictive and safety claims remain forbidden;
- H6 matched rule-ablation candidate remains `inconclusive`; its exploratory conditional model has holdout R2 `-0.06296668096584646` and does not support a general rule-removal claim;
- all datasets, licenses, preprocessing declarations and raw/processed hashes are recorded in the aggregate evidence;
- clean command `docker run --rm fuzzyxai-q1 make reproduce-q1`: PASS;
- technical DoD after archive closure: 105 PASS, 0 BLOCKED, 3 OPEN_EXTERNAL.

Required boundaries:

- the real benchmarks demonstrate reproducible framework execution, not clinical, production or external-domain validity;
- the critical-rupture result is a structural diagnostic result only;
- the rule-ablation result is a controlled context-dependent candidate, not a confirmed general effect;
- independent comprehension, expert-action and domain-language reviews are still not run;
- merge to `main` and a stable release tag remain forbidden while any external gate is open.

Next step: run the three independent external protocols. Do not reopen or overwrite the frozen predecessor results.

## Full Empirical Validation

- Date: 2026-07-20
- Branch: `feat/full-empirical-validation`
- Final technical closure commit: `fc8705ececdcc58f6cc171017984d9c6af05dd45`
- Final full empirical CI run: `29707225733`
- Candidate status: full E1-E8 technical validation; stable release remains blocked

The current milestone adds a controlled, evidence-first validation layer without changing the defended chapter 2-3
operator semantics. Four deterministic modality contours contain 10,000 objects each. The full protocol measures
repeated rule ablation, explanation baselines, P1-P7 action policies, calibration, sensitivity, adaptive uncertainty
representations, critical-rupture association, and scalability. The Docker image runs the same one-command pipeline.

Measured boundaries must remain explicit:

- SHAP, LIME, Anchors, RuleFit, confidence, disagreement, reduced-history FuzzyXAI, and full FuzzyXAI are measured;
- the 50-pair rule-ablation experiment does not confirm a general subgroup-recall effect;
- adaptive selection uses `FML` for 55.22% of controlled objects and is non-inferior to always-FML in the declared risk metric;
- the critical-rupture indicator has incremental AUPRC `-0.12556024709557384`, so no safety or predictive-gain claim is allowed;
- the critical rupture remains a structural diagnostic indicator only;
- controlled multimodal results do not establish external-domain generalization;
- expert review and comprehension pilot remain `planned_not_run`; domain semantic review remains pending;
- merge to `main` and a stable tag remain forbidden while those external gates are open.

Public run `29707225733` passed protocol smoke, full E1-E8, checkout-independent Docker reproduction, final evidence
aggregation, archive verification, and the 90-item technical Definition of Done. Stable release remains blocked by
the three explicitly recorded external gates, not by a computational failure.

- Date: 2026-07-19
- Branch: `feat/universal-model-integration`
- Base: `79d39f61f02df1cf1d63fc92dd2a1ebebfef7de7`
- Universal API commit: `3dda3e3`
- Model evidence commit: `a76677a`
- CI correction commit: `fbfcdd3`
- Cross-runtime evidence commit: `39067b3`
- Candidate version: `1.3.0rc1`
- Release tag: not created

## Current Focus

The installable research framework remains the primary product. The generated DubnaXAI site stays quarantined.
This milestone adds capability-based model integration and measured explanation-quality disclosure without changing
the defended chapter 2-3 operator semantics.

## Implemented

- `ModelAdapterV2`, task/input/output contracts, capability descriptors, and native/derived/surrogate/external origin;
- priority adapter registry, explicit resolution report, lazy optional imports, and plugin entry-point discovery;
- sklearn linear, tree, ensemble, SVM, KNN, Naive Bayes, regression, and Pipeline adapters;
- optional XGBoost, LightGBM, CatBoost, PyTorch, TensorFlow/Keras, and ONNX adapters with separate tests;
- `ExplanationPlanner`, surrogate-fidelity blocking, adapter conformance, and quality reports;
- `explain_batch()`, `explain_global()`, `why_not()`, `compare_models()`, and capability reporting;
- deterministic benchmark with 24 classification and 10 regression configurations;
- checksummed runtime reports for sklearn, XGBoost, LightGBM, CatBoost, PyTorch, TensorFlow/Keras, and ONNX;
- automatic report merge, cross-version conflict detection, unified support matrix, API report, and quality report;
- frozen external A/B pilot package and external domain-language review package;
- aggregate Chapter 4 candidate evidence package.

## Measured Validation

- 34 core model configurations and six optional runtime integrations verified;
- unified model support matrix: `40/40 pass`;
- runtime reports: `14/14 pass` across Python 3.11 and Python 3.12;
- prediction parity rate: `1.0`;
- adapter conformance rate: `1.0`;
- explanation graph validation rate: `1.0`;
- strict MyPy: PASS;
- Ruff and compile checks: PASS;
- focused local compatibility/model/external-gate suite: `48 passed`, `6 skipped` optional runtimes;
- public readiness CI: `338 passed`, `6 skipped` on Python 3.11 and Python 3.12;
- public Octave JSON/dashboard smoke: PASS;
- public optional runtime CI: XGBoost, LightGBM, CatBoost, PyTorch, TensorFlow/Keras, and ONNX PASS on both Python versions;
- five public explanation APIs: PASS in all runtime reports;
- explanation-quality matrix: `40/40 pass`; measured top-reason stability in 36 configurations;
- readiness run: `29700288436`;
- universal model run: `29700288413`;
- existing measured checkpoint experiment and native rule ablation retained;
- model, pilot, domain-review, and Chapter 4 manifests: PASS.

The full regression suite was moved from the workstation to GitHub runners after the user reported Cursor
instability. Both supported Python jobs passed. This validates the feature branch, not `main` after merge.

## External Gates

- independent A/B comprehension pilot: `planned_not_run`, zero participants;
- regulated-domain dictionary review: `pending_external_review`;
- Chapter 4 computed evidence: PASS;
- demonstrated human comprehension: not claimed;
- release gate: `BLOCKED`;
- `v1.2.0` tag and merge to `main`: forbidden until external gates and main CI pass.

## Version Boundary

- `v1.2.0`: Human Explanation and empirical computational gate implemented; final tag blocked externally.
- `v1.3.0rc1`: universal tabular model integration and merged cross-runtime evidence candidate implemented on this branch.
- version path B selected: no retroactive stable `v1.2.0`; next allowed tag after external gates, main merge, and main CI is `v1.3.0rc2`.
- `v1.4.0`: anomaly, forecasting, text, image, and richer checkpoint integrations remain future scope.

## Archive Policy

- source archive is built only from a committed Git index with `python scripts/build_framework_release.py`;
- Chapter 4 candidate ZIP is reproducible but not a final-release claim;
- doctoral historical archive remains separate;
- generated site content and unrelated dirty-worktree artifacts must not enter the source archive.

## Next Step

Run the real external pilot and domain review. After both pass, review merge to `main`, require green main CI, rebuild
committed-index archives, and only then create a release tag. Do not claim `v1.4.0` support before modality-specific
adapters and benchmarks exist.
## FXAI-SELECTIVE-OBSERVER-FORMATIVE

- Date: 2026-07-20
- Branch: `feat/selective-observer-formative`
- Frozen predecessor: `e34e52fb8ae62ee1be043d6d5b26a0c9214a0572`
- Research phase: formative development
- Stable release: blocked

This milestone starts a new two-stage research cycle without modifying the predecessor evidence. It adds a grouped
out-of-fold selective risk controller with `accept`, `short_review`, `full_review` and `block`; preregisterable
confidence, uncertainty, explainer-disagreement and selective-risk baselines; separate risk-coverage and cost-review
comparisons; H5 action-contract validation separated from held-out error prediction; H6 planted-rule method checks
separated from low-redundancy matched-control confirmation; and an immutable stage-B protocol-lock contract.

The development package is intentionally claim-safe:

- controller source channels and controller selection predictions are out-of-fold;
- test records cannot be passed to development contracts;
- formative datasets and participants cannot overlap confirmatory identities;
- formative operating-point gains never enable a confirmatory claim;
- external-study files contain protocols and empty record lists only;
- the old H3, H5 predictive and H6 null results remain visible;
- no stable tag or merge is allowed during formative development.

Acceptance command: `make selective-observer-formative-check`. The next scientific action is formative usability and
expert-task piloting, followed by a signed/timestamped protocol lock. Only then may new datasets, participants and
experts be opened once for confirmation.

## FXAI-Q1-FINAL-CLOSURE

- Date: 2026-07-20
- Branch: `feat/q1-final-closure`
- Frozen base: `41c32af25242164144fd907e4850fa9d4f426bd1`
- Candidate status: technical closure PASS at `e34e52fb8ae62ee1be043d6d5b26a0c9214a0572`; external gates open
- Stable release: blocked

This milestone adds a final evidence-first validation boundary rather than replacing the defended operators or the
frozen predecessor experiments. It defines native multiclass tasks for Covertype, Fashion-MNIST, 20 Newsgroups and
ElectricDevices; measured explainer cohorts; separate H1-H5 results; a leakage-resistant two-dataset confirmatory H6
protocol; end-to-end scalability; claim registry 2.0; deterministic archive identity; and protected external-study
scorers. The generated DubnaXAI site remains quarantined.

Local validation at implementation time:

- Q1 final focused suite: `19 passed`;
- Ruff for the Q1 final package, scripts and tests: PASS;
- compileall: PASS;
- `scripts/q1_final/reproduce_all.py --profile smoke`: PASS;
- strict external verifier: expected FAIL with `domain_language_review`, `comprehension`, and `expert_action_review` open;
- public workflow `29740096302`: 9/9 jobs PASS, including four native modalities, rule ablation, scalability, Docker and aggregate verification;
- technical DoD: 161 PASS, 0 BLOCKED, 24 OPEN_EXTERNAL.

Release boundary:

- the four native multiclass jobs, required explainers, H1-H6, full scalability, Docker reproduction and archive
  verification must pass in `.github/workflows/q1-final-validation.yml` before technical closure;
- external scorers never generate participant or reviewer records;
- an approved or exempt ethics record, genuine anonymized responses and signed records are required to close an
  external gate;
- null or negative H3, H5 predictive, H6, comprehension or expert-action results must remain visible and must remove
  the corresponding positive claim;
- no merge to `main`, stable `v1.3.0` tag or stable GitHub release is allowed while mandatory gates are open;
- archive commit and CI run IDs are written at build time to `release_evidence/q1_final/run_identity.json`.

Next step: preserve the technical result and conduct the three independent external protocols. Do not manufacture
responses or promote formative evidence to a confirmatory claim.
